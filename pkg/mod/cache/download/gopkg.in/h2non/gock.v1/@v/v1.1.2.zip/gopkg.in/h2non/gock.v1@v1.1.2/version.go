package gock

// Version defines the current package semantic version.
const Version = "1.1.2"
