# ddl-parser

[![Go](https://github.com/zeromicro/ddl-parser/actions/workflows/go.yml/badge.svg?branch=main)](https://github.com/zeromicro/ddl-parser/actions/workflows/go.yml)
[![go-zero](https://img.shields.io/badge/Github-go--zero-brightgreen?logo=github)](https://github.com/tal-tech/go-zero)
[![license](https://img.shields.io/badge/License-MIT-blue)](https://github.com/zeromicro/ddl-parser/blob/main/LICENSE)
[![license](https://img.shields.io/badge/Release-V1.0-red)](https://github.com/zeromicro/ddl-parser/releases)

A tool to parse mysql ddl, it's only does work for goctl!
