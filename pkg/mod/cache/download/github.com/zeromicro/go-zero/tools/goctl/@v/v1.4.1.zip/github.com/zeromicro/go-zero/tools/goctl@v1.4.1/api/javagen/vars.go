package javagen

const modelDir = "model"
