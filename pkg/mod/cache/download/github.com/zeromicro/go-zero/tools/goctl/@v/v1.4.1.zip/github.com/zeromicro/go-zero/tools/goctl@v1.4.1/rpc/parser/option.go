package parser

import "github.com/emicklei/proto"

// Option embeds proto.Option
type Option struct {
	*proto.Option
}
