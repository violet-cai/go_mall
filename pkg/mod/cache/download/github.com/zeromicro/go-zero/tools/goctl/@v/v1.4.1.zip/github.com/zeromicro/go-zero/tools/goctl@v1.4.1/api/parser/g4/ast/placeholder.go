package ast

// Holder defines a default instance for PlaceHolder
var Holder PlaceHolder

// PlaceHolder defines an empty struct
type PlaceHolder struct{}
