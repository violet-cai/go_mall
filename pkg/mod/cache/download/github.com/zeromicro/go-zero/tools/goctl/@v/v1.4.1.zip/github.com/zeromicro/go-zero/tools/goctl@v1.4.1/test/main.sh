#!/bin/bash

# main.sh is the entry point for the goctl tests.

# testing mongo code generation.
/bin/bash integration/model/mongo/mongo.sh
