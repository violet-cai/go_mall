//go:build windows
// +build windows

package migrate

func cancelOnSignals() {
}
