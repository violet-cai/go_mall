# goctl

English | [简体中文](readme-cn.md)

Read document at https://go-zero.dev/docs/goctl/goctl