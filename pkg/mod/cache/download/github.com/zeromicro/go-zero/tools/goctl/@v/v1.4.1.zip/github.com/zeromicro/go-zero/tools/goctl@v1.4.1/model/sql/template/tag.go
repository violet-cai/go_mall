package template

// Tag defines a tag template text
const Tag = "`db:\"{{.field}}\"`"
