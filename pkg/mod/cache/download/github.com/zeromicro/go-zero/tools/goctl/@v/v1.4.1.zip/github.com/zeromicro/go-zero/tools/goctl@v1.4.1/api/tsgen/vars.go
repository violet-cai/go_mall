package tsgen

const (
	packagePrefix = "components."
	pathPrefix    = "pathPrefix"
)
