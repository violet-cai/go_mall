package model

import "github.com/zeromicro/go-zero/core/stores/sqlx"

// ErrNotFound types an alias for sqlx.ErrNotFound
var ErrNotFound = sqlx.ErrNotFound
