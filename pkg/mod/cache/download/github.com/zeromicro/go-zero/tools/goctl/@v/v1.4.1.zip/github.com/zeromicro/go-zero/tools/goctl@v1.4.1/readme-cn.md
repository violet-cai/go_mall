# goctl

[English](readme.md) | 简体中文

goctl 使用见文档 https://go-zero.dev/cn/docs/goctl/goctl/